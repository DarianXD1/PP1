
    fun main() {
       
        var text="      Titlu carte\n" + "       Nume Autor\n" + "\n" + "\n"+ "\n"+ "Capitolul 2:Nume capitol\n" + "   A fost odata       ca  niciodata..."+ "\n"+ "             2         "
        println(text)
        println("*".repeat(100))

        //elimina salturile la linie noua multiple
        text = text.replace("\n+".toRegex(), "\n")
        println(text)
        println("*".repeat(100))

        //elimina numarul paginii
        text = text.replace("\\s{3,}\\d\\s{3,}".toRegex(), "")
        println(text)
        println("*".repeat(100))

        //elimina numele capitolului
        text = text.replace("Capitolul\\s\\d+:\\w+[+\\s\\w-]*\n".toRegex(), "Capitolul:\n")
        println(text)
        println("*".repeat(100))

        //elimina numele autorului
        text = text.replace("\n\\s{5,}\\w+[+\\s\\w-]*\n".toRegex(), "\n")
        println(text)
        println("*".repeat(100))

        //elimina spatiile multiple
        text = text.replace("\\s+".toRegex(), " ")
        println(text)
        println("*".repeat(100))

    }

