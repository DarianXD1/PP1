package ro.mike.tuiasi
import org.jsoup.Jsoup
import org.jsoup.parser.Parser
import org.jsoup.select.Elements


data class item(var title: String, var link: String, var description: String, var pubDate: String)

fun main() {

    val url: String = "http://rss.cnn.com/rss/edition.rss"
    var parseDoc = Jsoup.connect(url).get()
    var items : Elements? = parseDoc?.select("item")

    val Lista= mutableListOf<item>()

    items?.forEach {
        var title = it.getElementsByTag("title").html()
        var link = it.getElementsByTag("link").html()
        var description = it.getElementsByTag("description").html()
        var pubDate = it.getElementsByTag("pubDate").html()

        Lista.add(item(title, link, description, pubDate))

    }

    for(it in Lista)
    {
        println("Titlu: " + it.title.toString())
        println("Link: " + it.link.toString())
        println("*".repeat(100))
    }

}
