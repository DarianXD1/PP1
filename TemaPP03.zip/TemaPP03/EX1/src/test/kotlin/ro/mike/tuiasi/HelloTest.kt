package ro.mike.tuiasi

import org.junit.Test
import kotlin.test.assertEquals

class HelloTest {

}
